
/**
 * Package for copy number variation detection of genes (e.g., Aplification of BRCA1)
 * Currently, this package is not used by SETH
 *
 */
package cnveth;