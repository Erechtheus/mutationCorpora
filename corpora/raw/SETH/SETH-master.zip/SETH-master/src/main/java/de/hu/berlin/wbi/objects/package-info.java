/**
 * Package with the main data objects.
 * @author Philippe Thomas
 *
 */
package de.hu.berlin.wbi.objects;
