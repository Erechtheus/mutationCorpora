/**
 * Various common work-flows based on SNP normalization.
 *  
 * @author Philippe Thomas
 *
 */
package de.hu.berlin.wbi.process;
