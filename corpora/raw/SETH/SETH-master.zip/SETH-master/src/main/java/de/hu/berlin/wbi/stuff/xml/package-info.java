/**
 * This package is relevant to rebuild the MySQL-Database for SNP normalization purposes
 * @author Philippe Thomas
 */
package de.hu.berlin.wbi.stuff.xml;