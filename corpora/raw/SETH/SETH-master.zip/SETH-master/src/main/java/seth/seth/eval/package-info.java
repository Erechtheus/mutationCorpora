/**
 *
 * Code for applying and evaluating SETH on various corpora
 * @author Philippe Thomas
 */
package seth.seth.eval;