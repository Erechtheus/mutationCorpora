/**
 * Package contains most logic of SETH
 * @author Philippe Thomas
 */
package seth;