/**
 * Package to evaluate performance of SETH on the osiris dataset
 *  
 * @author Philippe Thomas
 *
 */
package de.hu.berlin.wbi.process.osiris;
