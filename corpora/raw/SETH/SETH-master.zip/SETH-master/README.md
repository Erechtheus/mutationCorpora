
See http://rockt.github.com/SETH/

## Contributors
- Philippe Thomas
- Tim Rocktäschel
- Yvonne Mayer
- Johannes Kirschnick
- Eugene Brevdo
