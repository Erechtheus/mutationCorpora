Osiris v1.2 corpus. Downloaded from https://sites.google.com/site/laurafurlongweb/databases-and-tools/corpora/








BibTex citation:
@ARTICLE{Furlong2008,
  author = {Laura I Furlong and Holger Dach and Martin Hofmann-Apitius and Ferran Sanz},
  title = {OSIRISv1.2: a named entity recognition system for sequence variants
  of genes in biomedical literature.},
  journal = {BMC Bioinformatics},
  year = {2008},
  volume = {9},
  pages = {84},
  doi = {10.1186/1471-2105-9-84},
  pii = {1471-2105-9-84},
  pmid = {18251998},
  timestamp = {2013.01.15},
  url = {http://dx.doi.org/10.1186/1471-2105-9-84}
}
