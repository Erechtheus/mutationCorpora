SNP normalization corpus downloaded from (http://www.scai.fraunhofer.de/snp-normalization-corpus.html).
SNPs are associated with unambiguous dbSNP identifiers.


BibTex citation:
@Article{thomas2011,
	author = {Thomas, Philippe and Klinger, Roman and Furlong, Laura and Hofmann-Apitius, Martin and Friedrich, Christoph}, 
	title = {Challenges in the association of human single nucleotide polymorphism mentions with unique database identifiers}, 
	journal = {BMC Bioinformatics}, 
	volume = {12}, 
	year = {2011}, 
	number = {Suppl 4}, 
	pages = {S4}, 
	url = {http://www.biomedcentral.com/1471-2105/11/S4/S4}, 
	doi = {10.1186/1471-2105-12-S4-S4}, 
	issn = {1471-2105} 
}
