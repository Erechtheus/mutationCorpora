SNP named entity recognition corpus consisting of 630 PubMed citations.

corpus.txt contains concatenated abstracts
yearMapping.txt contains a mapping from PMID to publicationYear
annotations/ contains 630 annotation files in BRAT/Stav format
 We annotated mutations, genes, and relations. However, for evaluation purpose we only used the mutation data. 
