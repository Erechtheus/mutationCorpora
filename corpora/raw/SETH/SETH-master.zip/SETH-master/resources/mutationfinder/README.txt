MutationFinder distribution, required for NER evaluation and for the MutationFinder corpus


BibTex Citation:
@ARTICLE{Caporaso2007,
  author = {J. Gregory Caporaso and William A Baumgartner and David A Randolph and K. Bretonnel Cohen and Lawrence Hunter},
  title = {MutationFinder: a high-performance system for extracting point mutation mentions from text.},
  journal = {Bioinformatics},
  year = {2007},
  volume = {23},
  pages = {1862--1865},
  number = {14},
  month = {Jul},
  pii = {btm235},
  pmid = {17495998},
  timestamp = {2013.01.15},
  url = {http://dx.doi.org/10.1093/bioinformatics/btm235}
}

