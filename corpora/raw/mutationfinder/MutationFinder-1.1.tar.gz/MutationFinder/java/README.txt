See MutationFinder/doc/README.txt for a general description of MutationFinder,
and MutationFinder/doc/README_java.txt for a description of the java 
implmentation.
