See MutationFinder/doc/README.txt for a general description of MutationFinder,
and MutationFinder/doc/README_perl.txt for a description of the perl 
implmentation.
